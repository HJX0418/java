package whut.info.reflectCase;

public abstract interface IBaseParser {
	public abstract void parse(String s);
}
