package whut.info.reflectCase;

public class CParser implements IBaseParser{
	public CParser() {
		System.out.println("new CParser instance");
	}
	public void parse(String s) {
		System.out.println("pase the message by C parser");
	}
}
