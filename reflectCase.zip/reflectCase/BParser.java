package whut.info.reflectCase;

public class BParser implements IBaseParser{
	public BParser() {
		System.out.println("new BParser instance");
	}
	public void parse(String s) {
		System.out.println("pase the message by B parser");
	}
}
